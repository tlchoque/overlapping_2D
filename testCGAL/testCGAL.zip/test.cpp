
#include <iostream>
#include <deque>
#include <time.h>
#include "Imesh2D.h"
#include "vtk.h"

using namespace std;

const int windowWidth = 800;
const int windowHeight = 800;
const int numPoints = 500;
const double maxAngle = 95;

#define PI 3.14159265

struct coordinate{
	double x,y;
	coordinate(){}
	coordinate(double xt, double yt){
		x=xt;
		y=yt;
	}
};

vector<coordinate> vcor;

void randomize(){
	  srand((time_t) time(NULL));  
}

int random(int n){
	  return rand()%n; 
}

void drawMesh(Delaunay & dt){
	unsigned char grey[3] = {192,192,192};
	unsigned char red[3] = {255, 0, 0};
	unsigned char blue[3] = {0, 255, 0};
	unsigned char *colorsArray[3] = {grey,red,blue};

	Vertex v;
	vtkSmartPointer<vtkPoints> points = vtkSmartPointer<vtkPoints>::New();
	int k=0;
	for (Vertex_iterator vi = dt.vertices_begin(); vi != dt.vertices_end(); vi++) { 
		points->InsertNextPoint(vi->point().x(), vi->point().y(), 0.0);
		vi->info().index=k;
		++k;
	} 

	vtkSmartPointer<vtkUnsignedCharArray> colors =  vtkSmartPointer<vtkUnsignedCharArray>::New();
	colors->SetNumberOfComponents(3);
	colors->SetName("Colors");

	vtkSmartPointer<vtkCellArray> triangles = vtkSmartPointer<vtkCellArray>::New();
	vtkSmartPointer<vtkTriangle> triangle = vtkSmartPointer<vtkTriangle>::New();

	Finite_faces_iterator it;
	for(it = dt.finite_faces_begin(); it != dt.finite_faces_end(); it++){
		colors->InsertNextTupleValue(*(colorsArray + it->info().label));
		triangle->GetPointIds()->SetId(0, it->vertex(0)->info().index);
		triangle->GetPointIds()->SetId(1, it->vertex(1)->info().index);
		triangle->GetPointIds()->SetId(2, it->vertex(2)->info().index);
		triangles->InsertNextCell(triangle);
	}

	vtkSmartPointer<vtkCellArray> lines = vtkSmartPointer<vtkCellArray>::New();
	vtkSmartPointer<vtkLine> line = vtkSmartPointer<vtkLine>::New();

	for(Edge_iterator ei=dt.finite_edges_begin();ei!=dt.finite_edges_end(); ei++){
		Face f = (ei->first);
		int i = ei->second;
		Vertex vs = f->vertex(f->cw(i));
		Vertex vt = f->vertex(f->ccw(i));
		line->GetPointIds()->SetId(0,vs->info().index); 
		line->GetPointIds()->SetId(1,vt->info().index);
		lines->InsertNextCell(line);
	}

	vtkSmartPointer<vtkPolyData> polydata = vtkSmartPointer<vtkPolyData>::New();
	polydata->SetPoints(points);
	polydata->SetPolys(triangles);
	polydata->GetCellData()->SetScalars(colors);
	
	vtkSmartPointer<vtkPolyData> linesPolyData = vtkSmartPointer<vtkPolyData>::New();
	linesPolyData->SetPoints(points);
	linesPolyData->SetLines(lines);

	vtkSmartPointer<vtkPolyDataMapper> mapper =  vtkSmartPointer<vtkPolyDataMapper>::New();
	vtkSmartPointer<vtkPolyDataMapper> mapper2 =  vtkSmartPointer<vtkPolyDataMapper>::New();
#if VTK_MAJOR_VERSION <= 5
	mapper->SetInputConnection(polydata->GetProducerPort());
	mapper2->SetInputConnection(linesPolyData->GetProducerPort());
#else
	mapper->SetInputData(polydata);
	mapper2->SetInputData(linesPolyData);
#endif
	vtkSmartPointer<vtkActor> actor = vtkSmartPointer<vtkActor>::New();
	actor->SetMapper(mapper);

	vtkSmartPointer<vtkActor> actor2 = vtkSmartPointer<vtkActor>::New();
	actor2->SetMapper(mapper2);
 
	vtkSmartPointer<vtkRenderer> renderer = vtkSmartPointer<vtkRenderer>::New();
	vtkSmartPointer<vtkRenderWindow> renderWindow = vtkSmartPointer<vtkRenderWindow>::New();
	renderWindow->AddRenderer(renderer);
	vtkSmartPointer<vtkRenderWindowInteractor> renderWindowInteractor = vtkSmartPointer<vtkRenderWindowInteractor>::New();
	renderWindowInteractor->SetRenderWindow(renderWindow);

	renderer->AddActor(actor);
	renderer->AddActor(actor2);
	renderer->ResetCamera();
 
	renderWindow->Render();
	renderWindowInteractor->Start();
}

void generate(vector<Point>& rPoints){
	int max = 10;
	coordinate *p = new coordinate[max]; 
	coordinate *p_Temp = NULL;   
	int nv = 0;
	int ntri = 0;
	double x, y;
	bool ok = false;
	//randomize();
	nv = 0;
	p = new coordinate[max];
	while (nv != numPoints){
		do{
			ok = true;
			x = (double)random(windowWidth);
			y = (double)random(windowHeight);
			for(int n_Cpt = 0; n_Cpt <= nv; ++n_Cpt){
				if((x == p[n_Cpt].x) && (y == p[n_Cpt].y)) {ok = false;break;}
			}
		}while(!ok);
		if (nv >= max){
			max = max * 2;            
			p_Temp = new coordinate[max]; 
			for (int i = 0; i < nv; ++i) {
				p_Temp[i] = p[i];  
			}
			delete []p;  
			p = p_Temp; 
		}   
		p[nv].x = x;
		p[nv].y = y;
		nv++;
	}
	for (int i = 0; i < nv; ++i) {
		rPoints.push_back(Point(p[i].x,p[i].y));     
	}
}
	
int bigger(double x,double y,double s,double b){
	double y2=s*x+b;
	if(y > y2)
		return 1;
	else return 0;
}

void load_points(vector<Point>& rPoints){
  rPoints.push_back(Point(100,100));   // first point
  rPoints.push_back(Point(600,100));   // second point
  rPoints.push_back(Point(300,400));   // third point
  rPoints.push_back(Point(400,800));   // fourth point
 }

double norm(double x,double y){
	return sqrt( pow(x,2) + pow(y,2) );
}

double getAngle(Vertex a, Vertex b,Vertex c){
		return acos( ( (a->point().x()-b->point().x())*(c->point().x()-b->point().x()) + (a->point().y()-b->point().y())*(c->point().y()-b->point().y()) )/( norm(a->point().x()-b->point().x(),a->point().y()-b->point().y())*norm(c->point().x()-b->point().x(),c->point().y()-b->point().y()) ) )* 180.0 / PI;
}

void segmentedCircle(Delaunay & dt,double xc,double yc, double r){
	Finite_faces_iterator it;
	for(it = dt.finite_faces_begin(); it != dt.finite_faces_end(); it++){
		double r2 =r*r;
		if( (pow(dt.triangle(it)[0].x()-xc, 2)+pow(dt.triangle(it)[0].y()-yc , 2) < r2 ) && 
			(pow(dt.triangle(it)[1].x()-xc, 2)+pow(dt.triangle(it)[1].y()-yc , 2) < r2  ) && 
			(pow(dt.triangle(it)[2].x()-xc, 2)+pow(dt.triangle(it)[2].y()-yc , 2) < r2  ) ){
			it->info().label = 1;
		}	
		else it->info().label = 0;
	}
}

void segmentedSquare(Delaunay & dt, double x, double y,double side){
	Finite_faces_iterator it;
	double left,right,up,down;
	left=x;right=x+side;up=y;down=y+side;
	for(it = dt.finite_faces_begin(); it != dt.finite_faces_end(); it++){
		if( (dt.triangle(it)[0].x() < right && dt.triangle(it)[0].x() > left && dt.triangle(it)[0].y() < down) && (dt.triangle(it)[0].y() > up) &&
			(dt.triangle(it)[1].x() < right && dt.triangle(it)[1].x() > left && dt.triangle(it)[1].y() < down) && (dt.triangle(it)[1].y() > up) &&
			(dt.triangle(it)[2].x() < right && dt.triangle(it)[2].x() > left && dt.triangle(it)[2].y() < down) && (dt.triangle(it)[2].y() > up) ){
			it->info().label = 2;
		}
	}
}

void segmentedLine(Delaunay & dt, double s, double b){
	Finite_faces_iterator it;
	for(it = dt.finite_faces_begin(); it != dt.finite_faces_end(); it++){
		if( bigger(dt.triangle(it)[0].x(),dt.triangle(it)[0].y(),s,b) && 
			bigger(dt.triangle(it)[1].x(),dt.triangle(it)[1].y(),s,b) && 
			bigger(dt.triangle(it)[2].x(),dt.triangle(it)[2].y(),s,b) ){
			it->info().label = 3;
		}
	}
}

void getBoundary(Delaunay & dt, vector<pair<Vertex,Vertex>> &boundary){
	boundary.clear();
	for(Edge_iterator ei=dt.finite_edges_begin();ei!=dt.finite_edges_end(); ei++){
		Delaunay::Face &f1 = *(ei->first);
		int i = ei->second;
		Delaunay::Face &f2 = *f1.neighbor(i);

		//cout<<f1.info().label<<" "<<f2.info().label<<endl;
		if(f1.info().label == f2.info().label){
			continue;
		}
		if(f1.info().label < 0 || f2.info().label < 0){
			continue;
		}
		Vertex vs = f1.vertex(f1.cw(i));
		Vertex vt = f1.vertex(f1.ccw(i));
		boundary.push_back(make_pair(vs,vt));
	}
}

void getArrayBoundaries(Delaunay & dt,vector<pair<Vertex,Vertex>> &boundary, vector<deque<Vertex>> &boundaries ){
	boundaries.clear();
	deque<Vertex> pointArray;
	Vertex t=0,s=0,cen=0;
	int k=0;
	bool state=0;
	pointArray.clear();
	while(boundary.size() != 0){		
		if(pointArray.size() == 0){
			state=0;
			pointArray.push_back(boundary[0].first);
			s = boundary[0].first;
			pointArray.push_back(boundary[0].second);
			t = boundary[0].second;
			boundary.erase(boundary.begin());
			cen=t;
		}
		k=-1;
		for(int j=0;j < boundary.size();++j){
			if(cen == boundary[j].first){
				k=j;
				cen = boundary[j].second;
				break;
			}
			else if(cen == boundary[j].second){
				k=j;
				cen = boundary[j].first;
				break;
			}
		}
		if(k!=-1){
			if(state == 0)
				pointArray.push_back(cen);	
			else
				pointArray.push_front(cen);
			boundary.erase(boundary.begin() + k);
		}
		else {
			if(boundary.size() == 0){
				boundaries.push_back(pointArray);
				pointArray.clear();
			}
			else{
				if(state == 0){
					cen=s;
					state=1;
				}
				else{
					boundaries.push_back(pointArray);
					pointArray.clear();
				}
			}
		}
	}
	if(pointArray.size() != 0){
		boundaries.push_back(pointArray);
	}

}

void getBoundaryAngles(vector<deque<Vertex>> & boundaries){
	Vertex v;
	double t;
	for(int i=0;i<boundaries.size();++i){
		for(int j=1;j<boundaries[i].size()-1;++j){
			t=getAngle(boundaries[i][j-1],boundaries[i][j],boundaries[i][j+1]);
			boundaries[i][j]->info().angle=t;
		}
		if(boundaries[i][0] == boundaries[i][boundaries[i].size()-1]){
			t=getAngle(boundaries[i][boundaries[i].size()-2],boundaries[i][0],boundaries[i][1]);
			boundaries[i][0]->info().angle=t;
		}
		else{
			boundaries[i][0]->info().angle=180.0;
		}
	}
}

int getLowerRegion(Delaunay & dt,Vertex v){
	Vertex u;
	Vertex_circulator vc_start = dt.incident_vertices(v);
	Vertex_circulator vc = vc_start;

	Face_circulator fc_start = dt.incident_faces(v);
	Face_circulator fc = fc_start;

	double sum=0;
	int label=fc->info().label;
	int opositeLabel=0;;
	do{
		u=vc;
		++vc;
		if(fc->info().label == label)
			sum+=getAngle(u,v,vc);
		else
			opositeLabel=fc->info().label;
		++fc;
	} while (vc!= vc_start);
	if(sum < v->info().angle+2)
		return opositeLabel;
	else
		return label;
}

void setlabel(Delaunay & dt, Vertex v, int label){
	Face_circulator fc_start = dt.incident_faces(v);
	Face_circulator fc = fc_start;
	do{
		fc->info().label=label;
		++fc;
	} while (fc!= fc_start);
}

void relabeling(Delaunay & dt, vector<deque<Vertex>> & boundaries){
	vcor.clear();	
	bool state=0;
	for(int i=0;i<boundaries.size();++i){
		for(int j=0;j<boundaries[i].size()-1;++j){
			//if(state==1)	state=0;
			if(boundaries[i][j]->info().angle < maxAngle ){
				cout<<boundaries[i][j]->point()<<endl;				
				cout<<" region label: "<<getLowerRegion(dt,boundaries[i][j])<<endl;
				vcor.push_back(coordinate(boundaries[i][j]->point().x(),boundaries[i][j]->point().y()));
				setlabel( dt,boundaries[i][j],getLowerRegion(dt,boundaries[i][j]));
				++j;
				//state=1;
			}
		}
	}
}

double getArea(Vertex pi, Vertex pj,Vertex pk){
	return ( (pj->point().x() - pi->point().x())*(pk->point().y()-pi->point().y()) - (pk->point().x() - pi->point().x())*(pj->point().y()-pi->point().y()) )/2;
}

double getEle(Vertex p1, Vertex p3){
	return norm(p3->point().x() - p1->point().x(),p3->point().y()-p1->point().y())/3;
}

void TSUR(vector<deque<Vertex>> & boundaries){
	coordinate t,n;
	for(int k=0;k < 30;++k){
		for(int i=0;i<boundaries.size();++i){
			for(int j=0;j<boundaries[i].size()-3;++j){
				double L = getEle(boundaries[i][j],boundaries[i][j+3]);
				double A = getArea(boundaries[i][j],boundaries[i][j+1],boundaries[i][j+2]) + getArea(boundaries[i][j],boundaries[i][j+2],boundaries[i][j+3]);
				double h = A/(2*L);
				double nr = norm(boundaries[i][j+3]->point().x() - boundaries[i][j]->point().x(), boundaries[i][j+3]->point().y() - boundaries[i][j]->point().y());
				t.x = (boundaries[i][j+3]->point().x() - boundaries[i][j]->point().x())/nr;
				t.y = (boundaries[i][j+3]->point().y() - boundaries[i][j]->point().y())/nr;
				n.x = t.y;
				n.y = -t.x;
				boundaries[i][j+1]->set_point( Point(boundaries[i][j]->point().x()+ L*t.x + h*n.x,boundaries[i][j]->point().y() + L*t.y + h*n.y) );
				boundaries[i][j+2]->set_point( Point(boundaries[i][j]->point().x() + 2*L*t.x + h*n.x,boundaries[i][j]->point().y() + 2*L*t.y + h*n.y) );
			}
		}
	}
}

int main(){
	double radio = (double)windowWidth/2;
	/*CGAL::Random_points_in_square_2<Point> g(radio);
	Delaunay dt;

	for (int i=0; i<numPoints; ++i) 
		dt.insert( Point((*g++).x() + radio,(*g++).y() + radio)); */

	vector<Point> points;
	generate(points);

	Delaunay dt;
	dt.insert(points.begin(),points.end());


	double xc,yc,r;
	xc=(double)0;
	yc=(double)(windowHeight);
	r=(double)(windowHeight);

	double x,y,side;
	x=(double)random(radio);
	y=(double)random(radio);
	side=(double)random(radio);

	segmentedCircle(dt,xc,yc,r);
	//segmentedSquare(dt,x,y,side);
	vector<pair<Vertex,Vertex>> boundary;
	vector<deque<Vertex>> boundaries;

	/*for(int i=0;i<5;++i){
		getBoundary(dt,boundary);		
		getArrayBoundaries(dt,boundary,boundaries);
		getBoundaryAngles(boundaries);
		relabeling(dt,boundaries);
	}

	getBoundary(dt,boundary);	
	getArrayBoundaries(dt,boundary,boundaries);
	TSUR(boundaries);*/

	drawMesh(dt);
	getchar();
	return 0;
}

